package entity.enums;

public enum EducationLevel {
    ASSOCIATE,
    BACHELOR,
    MASTER,
    PHD
}
