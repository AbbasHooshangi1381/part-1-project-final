package service;

import base.service.BaseService;
import entity.Lesson;

public interface LessonService extends BaseService<Lesson, Long> {
}
