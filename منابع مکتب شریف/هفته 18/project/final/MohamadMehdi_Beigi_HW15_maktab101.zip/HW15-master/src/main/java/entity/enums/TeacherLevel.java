package entity.enums;

public enum TeacherLevel {
    FACULTY_MEMBER,
    TUITION,

}
