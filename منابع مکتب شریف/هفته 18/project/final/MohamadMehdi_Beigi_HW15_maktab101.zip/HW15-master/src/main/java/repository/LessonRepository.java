package repository;

import base.repository.BaseRepository;
import entity.Lesson;


public interface LessonRepository extends BaseRepository<Lesson, Long> {
}
