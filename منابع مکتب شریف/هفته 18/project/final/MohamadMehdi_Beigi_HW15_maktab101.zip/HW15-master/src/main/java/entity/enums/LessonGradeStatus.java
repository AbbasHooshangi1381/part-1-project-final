package entity.enums;

public enum LessonGradeStatus {
    PASS,
    NOT_PASS
}
